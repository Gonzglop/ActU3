
import entity.User;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import java.util.Date;

@SuppressWarnings("ALL")
public class Main {
    public static void main(String[] args) {

        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("default");
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        //CREAR
        User user = new User();
        user.setName("Gonzalo");
        user.setBirthdDate(new Date(88,12,16));
        entityManager.persist(user);
        entityManager.flush();


        entityManager.getTransaction().commit();
        entityManager.close();
        entityManagerFactory.close();
    }
}
