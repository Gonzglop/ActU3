package entity;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name= "USUARIOS")
public class User {
    @Id
    @Column(name = "idUsuario")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "Nombre", length = 48)
    private String name;
    @Column(name = "FechaCumpleanyos")
    @Temporal(TemporalType.DATE)
    private Date birthdDate;

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getBirthdDate() {
        return birthdDate;
    }

    public void setBirthdDate(Date birthdDate) {
        this.birthdDate = birthdDate;
    }
}
