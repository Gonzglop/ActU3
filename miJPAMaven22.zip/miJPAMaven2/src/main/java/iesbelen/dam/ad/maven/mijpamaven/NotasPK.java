package iesbelen.dam.ad.maven.mijpamaven;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class NotasPK implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Column
	private String dni;
	
	@Column
	private int cod;
	
	
	
	public String getDni() {
		return dni;
	}
	public void setDni(String dni) {
		this.dni = dni;
	}
	public int getCod() {
		return cod;
	}
	public void setCod(int cod) {
		this.cod = cod;
	}
	@Override
	public int hashCode() {
		return Objects.hash(cod, dni);
	}
	public NotasPK() {
		super();
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NotasPK other = (NotasPK) obj;
		return cod == other.cod && Objects.equals(dni, other.dni);
	}
	
}