public class Datos {
    final static String[][] arrayClientes = {
            {"54320198V", "Pablo", "Carvajal","Calle Serrano 6","pablo@gmail.com","666888777"},
            {"23420198X", "Juan", "Castro","Calle Omar 2", "juan@gmail.com","666888555"}
    };

    final static String[][] arrayCoches = {
            {"9098DFD", "FORFOUR", "SMART","AZUL","54320198V"},
            {"1414ASD", "YARIS", "TOYOTA","BLANCO", "23420198X"}
    };

    final static String dni = "54320198V";

    final static String matricula = "1414ASD";
}
