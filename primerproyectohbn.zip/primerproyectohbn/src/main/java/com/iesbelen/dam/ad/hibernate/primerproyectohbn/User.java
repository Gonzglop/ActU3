package com.iesbelen.dam.ad.hibernate.primerproyectohbn;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class User {
	@Id
	private int id;
	private String userName;
	private String userMesagger;
	public User() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserMesagger() {
		return userMesagger;
	}
	public void setUserMesagger(String userMesagger) {
		this.userMesagger = userMesagger;
	}

}
