package com.iesbelen.dam.ad.hibernate.primerproyectohbn;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        
        StandardServiceRegistry sr = new StandardServiceRegistryBuilder().configure().build();
        
        SessionFactory sf = new MetadataSources(sr).buildMetadata().buildSessionFactory();
        
//        Abrimos la sesión
        Session session = sf.openSession();
        User user = new User();
        user.setId(1);
        user.setUserName("Pepe");
        user.setUserMesagger("Hello world from Pepe");
        
        User user2 = new User();
        user2.setId(2);
        user2.setUserName("Juan");
        user2.setUserMesagger("Hello world from Juan");
        
        session.getTransaction().begin();
        session.persist(user);
        session.persist(user2);
        session.getTransaction().commit();
        
        session.close();
        sf.close();  
    }
}
