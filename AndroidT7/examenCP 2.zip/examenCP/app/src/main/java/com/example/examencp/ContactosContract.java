package com.example.examencp;

import static com.example.examencp.ContactosProvider.URI_CONTENIDO;

import android.net.Uri;
import android.provider.BaseColumns;

public final class ContactosContract {

    private ContactosContract() {}

    public static class ContactoEntry implements BaseColumns {
        public static final String TABLE_NAME = "contactos";
        public static final String COLUMN_NAME_NOMBRE = "nombre";
        public static final String COLUMN_NAME_TELEFONO = "telefono";
        public static final String COLUMN_NAME_AVATAR = "avatar";

        /*
        public static Uri crearUriContacto(long id) {
            return URI_CONTENIDO.buildUpon().appendPath(String.valueOf(id)).build();
        }

         */
    }

}
