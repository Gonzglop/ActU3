package com.example.examencp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    EditText txtNombre = findViewById(R.id.editTextNombre);
    EditText txtTelefono = findViewById(R.id.editTextTelefono);
    Button btnAddContact = findViewById(R.id.btn_add_contacto);
    ViewGroup layoutAddContact = findViewById(R.id.layoutDatosContacto);
    Button btnAdd = findViewById(R.id.btn_add_contacto);
    Button btnCancelar = findViewById(R.id.btn_cancelar);
    Button btnModificar = findViewById(R.id.btn_modificar);
    ListView listaContactos = findViewById(R.id.lista_contactos);
    //List<Contacto> contactos = new ArrayList<>();


    Spinner spinnerImagen = findViewById(R.id.spinner_imagen);



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //registerForContextMenu(listaContactos);


        List<Integer> images = Arrays.asList(
                R.drawable.batman,
                R.drawable.capi,
                R.drawable.deadpool,
                R.drawable.furia,
                R.drawable.hulk,
                R.drawable.ironman,
                R.drawable.lobezno,
                R.drawable.spiderman,
                R.drawable.thor,
                R.drawable.wonderwoman
        );

        ImageAdapter adapter = new ImageAdapter(this, images);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerImagen.setAdapter(adapter);

        spinnerImagen.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                int avatarId = (int) parent.getItemAtPosition(position);
                // Hacer algo con la referencia de la imagen seleccionada en drawable (avatarId)
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // No se seleccionó nada
            }
        });

        /*

        // Asignar escuchador de eventos a la imagen addContact
        btnAddContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Mostrar la zona de añadir/modificar contactos y ocultar los botones de modificar
                layoutAddContact.setVisibility(View.VISIBLE);
                btnAdd.setVisibility(View.VISIBLE);
                btnCancelar.setVisibility(View.VISIBLE);
                mostrarLayout(true, null);
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Creamos un nuevo contacto con los datos suministrados
                Contacto contacto = new Contacto();
                contacto.setNombre(txtNombre.getText().toString());
                contacto.setTelefono(txtTelefono.getText().toString());
                contacto.setAvatar(spinnerImagen.getSelectedItemPosition());

                // Insertamos el contacto en la base de datos a través del Content Provider
                getContentResolver().insert(ContactosProvider.URI_CONTENIDO, contacto.getContentValues());

                // Mostramos la lista actualizada de contactos
                mostrarContactos();
                // Ocultamos la zona de añadir/modificar contactos
                mostrarLayout(false, null);
            }
        });
    }

    private void mostrarLayout(boolean mostrar, Contacto contacto) {

        if (mostrar) {
            // Si estamos en modo de modificación, rellenamos los campos
            if (contacto != null) {
                txtNombre.setText(contacto.getNombre());
                txtTelefono.setText(contacto.getTelefono());
                spinnerImagen.setSelection(contacto.getAvatar());
            }

            // Mostramos la zona de añadir/modificar contactos y los botones de añadir y cancelar
            layoutAddContact.setVisibility(View.VISIBLE);
            btnAdd.setVisibility(View.VISIBLE);
            btnCancelar.setVisibility(View.VISIBLE);
        } else {
            // Ocultamos la zona de añadir/modificar contactos y los botones de añadir, modificar y cancelar
            layoutAddContact.setVisibility(View.GONE);
            btnAdd.setVisibility(View.GONE);
            btnCancelar.setVisibility(View.GONE);

            // Limpiamos los campos de la zona de añadir/modificar contactos
            txtNombre.setText("");
            txtTelefono.setText("");
            spinnerImagen.setSelection(0);
        }
    }

    private void mostrarContactos() {
        // Obtener un cursor con todos los contactos del Content Provider
        Cursor cursor = getContentResolver().query(
                ContactosProvider.URI_CONTENIDO,
                null,
                null,
                null,
                null
        );

        // Configurar el SimpleCursorAdapter para mostrar los datos del cursor en el ListView
        String[] from = new String[]{
                ContactosDataSource.allColumns[1],
                ContactosDataSource.allColumns[2],
                ContactosDataSource.allColumns[3]
        };
        int[] to = {
                R.id.contacto_nombre,
                R.id.contacto_telefono,
                R.id.contacto_avatar
        };
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(
                this,
                R.layout.list_item_contacto,
                cursor,
                from,
                to,
                0
        );

        // Asignar el adaptador al ListView
        listaContactos.setAdapter(adapter);

         */
    }


    /*

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_contextual, menu);
    }

     */
/*
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        int position = info.position;
        ContactosAdapter adapter = new ContactosAdapter(this, contactos);
        Cursor cursor = (Cursor) adapter.getItem(position);
        @SuppressLint("Range") long id = cursor.getLong(cursor.getColumnIndex(ContactosContract.ContactoEntry._ID));
        switch (item.getItemId()) {
            case R.id.menu_borrar:
                borrarContacto(id);
                return true;
            case R.id.menu_modificar:
                mostrarModificarContacto(id);
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }


 */
    /*
    private void borrarContacto(long id) {
        getContentResolver().delete(ContactosContract.ContactoEntry.crearUriContacto(id), null, null);
        mostrarContactos();
    }

    private void mostrarModificarContacto(long id) {
        btnModificar.setVisibility(View.VISIBLE);
    }

     */
}