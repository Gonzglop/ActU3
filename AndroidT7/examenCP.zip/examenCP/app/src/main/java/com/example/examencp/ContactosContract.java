package com.example.examencp;

import android.provider.BaseColumns;

public final class ContactosContract {

    private ContactosContract() {}

    public static class ContactoEntry implements BaseColumns {
        public static final String TABLE_NAME = "contactos";
        public static final String COLUMN_NAME_NOMBRE = "nombre";
        public static final String COLUMN_NAME_TELEFONO = "telefono";
        public static final String COLUMN_NAME_AVATAR = "avatar";
    }

}
