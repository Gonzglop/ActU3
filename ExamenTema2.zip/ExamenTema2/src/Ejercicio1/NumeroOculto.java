package Ejercicio1;

import java.util.concurrent.Semaphore;

/**
 * Clase que contiene el número oculto y reacciona a los intentos de adivinación de los hilos adivinadores
 *
 * @author Álvaro Hernández Valero
 */

public class NumeroOculto {

    // ATRIBUTOS
    int numOculto;
    boolean gameOver;
    Semaphore semaphore;

    // CONSTRUCTOR
    public NumeroOculto(int numOculto) {
        this.numOculto = numOculto;
        this.gameOver = false;
        this.semaphore = new Semaphore(1);
    }

    // MÉTODOS
    public synchronized int propuestaNumero(int num) {
        if(gameOver)
            return -1;

        if(num != numOculto)
            return 0;

        gameOver = true;
        return 1;
    }
}
