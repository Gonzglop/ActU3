package Ejercicio1;

public class HiloAdivinador extends Thread {
    private static int totalAdivinadores = 1;
    private int numPrueba;
    private final int id;
    private final int MAX_TIME_GUESSING = 1000; // 2 seg
    NumeroOculto numOculto;

    // CONSTRUCTOR
    public HiloAdivinador(NumeroOculto numOculto) {
        id = totalAdivinadores++;
        this.numOculto = numOculto;
    }

    @Override
    public void run() {
        while(!numOculto.gameOver) {
            try{
                if(numOculto.semaphore.tryAcquire()) {
                    Thread.sleep((long) (Math.random() * MAX_TIME_GUESSING));
                    double f = Math.random()/Math.nextDown(1.0);
                    double x = 0*(1.0 - f) + 100*f;
                    numPrueba = (int) Math.round(x);

                    if(numOculto.propuestaNumero(numPrueba) == -1) {
                        System.out.printf("El hilo %d propone el número %d... pero el juego ya había terminado.\n",
                                id, numPrueba);
                    }
                    else if (numOculto.propuestaNumero(numPrueba) == 0) {
                        System.out.printf("El hilo %d propone el número %d... y falla.\n",
                                id, numPrueba);
                    }
                    else {
                        System.out.printf("El hilo %d propone el número %d... y acierta!!.\n",
                                id, numPrueba);
                    }
                    numOculto.semaphore.release();
                }
            }
            catch (InterruptedException iex) {
                iex.printStackTrace();
            }
        }
    }
}
