package Ejercicio1;

import javax.management.remote.rmi.RMIConnectionImpl_Stub;

/**
 * <h1>Ejercicio 1</h1>
 *
 * Un hilo genera un número al azar entre 0 y 100 y otros diez hilos deben intentar adivinarlo...
 *
 * @author Álvaro Hernández Valero
 */

public class Principal {
    public static void main(String[] args) {
        double f = Math.random()/Math.nextDown(1.0);
        double x = 0*(1.0 - f) + 100*f;
        int num = (int) Math.round(x);

        final int NUM_ADIVINADORES = 10;

        NumeroOculto numOculto = new NumeroOculto(num);
        System.out.println("EL NÚMERO A ACERTAR ES EL " + num);

        for (int i=0; i < NUM_ADIVINADORES; i++) {
            new HiloAdivinador(numOculto).start();
        }
    }
}
