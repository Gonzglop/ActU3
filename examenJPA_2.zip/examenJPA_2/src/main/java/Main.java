import entity.Concesionario;
import entity.Vehiculo;
import jakarta.persistence.*;

import java.util.Date;

public class Main {
    public static void main(String[] args) {

        Concesionario concesionario = new Concesionario("concesionarioComerc","ConcesionarioEmpres","Calle Barahona",345,"conce@gmail.com");
        Vehiculo veh1 = new Vehiculo("marca1","modelo1","rojo","1234",787777L);
        veh1.setFechaMatriculacion(new Date(89,03,11));
        Vehiculo veh2 = new Vehiculo("marca2","modelo2","azul","1235",7777L);
        veh2.setFechaMatriculacion(new Date(97,11,11));
        Vehiculo veh3 = new Vehiculo("marca3","modelo3","verde","1238",87777L);
        veh3.setFechaMatriculacion(new Date(62,12,28));

        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("default");
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        entityManager.persist(veh1);
        entityManager.persist(veh2);
        entityManager.persist(veh3);

        concesionario.addVehiculo(veh1);
        concesionario.addVehiculo(veh2);
        concesionario.addVehiculo(veh3);

        entityManager.persist(concesionario);

        TypedQuery<Vehiculo> queryVehiculos = entityManager.createNamedQuery("todosVehiculos", Vehiculo.class);
        for (Vehiculo vehiculo : queryVehiculos.getResultList()){
            System.out.println(vehiculo);
        }
        TypedQuery<Concesionario> queryConcesionario = entityManager.createNamedQuery("todosConcesionarios", Concesionario.class);
        for (Concesionario conces : queryConcesionario.getResultList()){
            System.out.println(conces);
        }

        entityManager.getTransaction().commit();
        entityManager.close();
        entityManagerFactory.close();
    }
}
