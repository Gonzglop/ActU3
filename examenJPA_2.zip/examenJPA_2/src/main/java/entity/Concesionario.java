package entity;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@NamedQuery(name = "todosConcesionarios",query = "select c from Concesionario c")

public class Concesionario {
    @Id
    @GeneratedValue
    private int idConcesionario;
    private String nombreComercial;
    private String nombreEmpresarial;
    private String direccionConcesionario;
    private int numTrabajadores;
    private String email;

    @OneToMany(mappedBy = "concesionario", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Vehiculo> vehiculos = new ArrayList<>();


    public Concesionario() {
    }

    public Concesionario(String nombreComercial, String nombreEmpresarial, String direccionConcesionario, int numTrabajadores, String email) {
        this.nombreComercial = nombreComercial;
        this.nombreEmpresarial = nombreEmpresarial;
        this.direccionConcesionario = direccionConcesionario;
        this.numTrabajadores = numTrabajadores;
        this.email = email;
    }

    public void setIdConcesionario(int idConcesionario) {
        this.idConcesionario = idConcesionario;
    }

    public int getIdConcesionario() {
        return idConcesionario;
    }

    public String getNombreComercial() {
        return nombreComercial;
    }

    public void setNombreComercial(String nombreComercial) {
        this.nombreComercial = nombreComercial;
    }

    public String getNombreEmpresarial() {
        return nombreEmpresarial;
    }

    public void setNombreEmpresarial(String nombreEmpresarial) {
        this.nombreEmpresarial = nombreEmpresarial;
    }

    public String getDireccionConcesionario() {
        return direccionConcesionario;
    }

    public void setDireccionConcesionario(String direccionConcesionario) {
        this.direccionConcesionario = direccionConcesionario;
    }

    public int getNumTrabajadores() {
        return numTrabajadores;
    }

    public void setNumTrabajadores(int numTrabajadores) {
        this.numTrabajadores = numTrabajadores;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public List<Vehiculo> getVehiculos() {
        return vehiculos;
    }

    public void setVehiculos(List<Vehiculo> vehiculos) {
        this.vehiculos = vehiculos;
    }

    @Override
    public String toString() {
        return "Concesionario{" +
                "idConcesionario=" + idConcesionario +
                ", nombreComercial='" + nombreComercial + '\'' +
                ", nombreEmpresarial='" + nombreEmpresarial + '\'' +
                ", direccionConcesionario='" + direccionConcesionario + '\'' +
                ", numTrabajadores=" + numTrabajadores +
                ", email='" + email + '\'' +
                ", vehiculos=\n" + vehiculos +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Concesionario)) return false;
        Concesionario that = (Concesionario) o;
        return getIdConcesionario() == that.getIdConcesionario();
    }

    @Override
    public int hashCode() {
        return Objects.hash(getIdConcesionario());
    }

    public void addVehiculo(Vehiculo vehiculo){
        vehiculos.add(vehiculo);
        vehiculo.setConcesionario(this);
    }
    public void removeVehiculo(Vehiculo vehiculo){
        vehiculos.remove(vehiculo);
        vehiculo.setConcesionario(null);
    }
}
