package entity;

import jakarta.persistence.*;
import org.hibernate.annotations.NaturalId;

import java.util.Date;
import java.util.Objects;

@Entity
@NamedQuery(name = "todosVehiculos",query = "select v from Vehiculo v")
public class Vehiculo {
    @Id
    @GeneratedValue
    private int idVehiculo;
    private String marca;
    private String modelo;
    private String color;
    @NaturalId
    private String matricula;
    @Temporal(TemporalType.DATE)
    private Date fechaMatriculacion;
    private Long numeroKilometros;

    @ManyToOne
    private Concesionario concesionario;



    public Vehiculo() {
    }

    public Vehiculo(String marca, String modelo, String color, String matricula, Long numeroKilometros) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.matricula = matricula;
        this.numeroKilometros = numeroKilometros;
    }

    public void setIdVehiculo(int idVehiculo) {
        this.idVehiculo = idVehiculo;
    }

    public int getIdVehiculo() {
        return idVehiculo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public Date getFechaMatriculacion() {
        return fechaMatriculacion;
    }

    public void setFechaMatriculacion(Date fechaMatriculacion) {
        this.fechaMatriculacion = fechaMatriculacion;
    }

    public Long getNumeroKilometros() {
        return numeroKilometros;
    }

    public void setNumeroKilometros(Long numeroKilometros) {
        this.numeroKilometros = numeroKilometros;
    }

    public Concesionario getConcesionario() {
        return concesionario;
    }

    public void setConcesionario(Concesionario concesionario) {
        this.concesionario = concesionario;
    }

    @Override
    public String toString() {
        return "Vehiculo{" +
                "idVehiculo=" + idVehiculo +
                ", marca='" + marca + '\'' +
                ", modelo='" + modelo + '\'' +
                ", color='" + color + '\'' +
                ", matricula='" + matricula + '\'' +
                ", fechaMatriculacion=" + fechaMatriculacion +
                ", numeroKilometros=" + numeroKilometros +
                "}\n";
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Vehiculo)) return false;
        Vehiculo vehiculo = (Vehiculo) o;
        return getIdVehiculo() == vehiculo.getIdVehiculo() && getMatricula().equals(vehiculo.getMatricula());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getIdVehiculo(), getMatricula());
    }
}
